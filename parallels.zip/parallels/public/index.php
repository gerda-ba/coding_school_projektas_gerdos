<?php
   require __DIR__ . '/../app/src/app.php';   
?>
    
<!DOCTYPE html>
<html lang="en"> <!--anglu kalba-->
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="web-design, photography, prototype, developer, designer">
    <meta name="author" content="Mark Cream, Antonio Paramo, Mario Ballote, Ben Bugatton">
    <title>Parallels</title>
    <script src="https://kit.fontawesome.com/6edb14f119.js" crossorigin="anonymous"></script><!-- idetas kit kodas iš fontawesome -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet"><!--šriftai iš fonts.google.com, arba atsisiusti ir isideti i folder ir nurodyti kelia iki jo-->
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../app/css/normalize.css"><!-- reset css -->
    <link rel="stylesheet" href="../app/css/style.css"><!-- mano css -->
</head> 
<body>
   <header class="site-header"> <!--tinklalapio hederis fonine spalva-->
       <div class="container1 flex-container"> 
           <div class="logo">
             <a href="#">
			    <img src="../app/images/logo.png" alt="Parallels-logo"> <!-- nerodant vaizdu rodys teksta, svarbu paieskos sistemoms-->
              </a>
           </div>
          <nav class="main-nav" ><!--navigacija, 5html galima tik nav-->
            <ul class="flex-container"> <!-- bootstrapas ir wordpresas naudoja ul-->
              <li><a href="#">Home</a></li> <!--# bus nuorodos-->
              <li><a href="#">Services</a></li>
              <li><a href="#">Portfolio</a></li>
              <li><a href="#">Pricing</a></li>
              <li><a href="#">About</a></li>
              <li><a href="#">Contact</a></li>
            </ul>
        </nav>
      </div >  
    </header>

    <!--BANER-WELCOME-->
         <section class="baner-welcome">    
             <div class="containera">
             <h1>Welcome to Parallels</h1>  <!-- galima naudoti viena kad teisingai sugeneruotų naršyklėse -->
             <p>Clean Responsive Theme</p> 
             <!-- <a href="#">
			    <img src="images/icons.png" alt="decoration" > 
              </a>--> 
           </div>  
         </section>
    
<!-- BANER-SERVICES--> 
         <section class="baner-services">
           <div class="container">
             <div class="section-heading">
              <h2>Our Services</h2>
                </div>
                 <div class="section-content flex-container">
                  <div class="services">
                   <img src="../app/images/1iconweb_03.png" alt="web-design">
                     <h3>WebDesign</h3>
                      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed eu varius dui. Nunc id 
scelerisque ligula.</p>
                  </div>
                   <div class="services">
                   <img src="../app/images/1iconiphon_03.png" alt="ui-design">
                     <h3>UIDesign</h3>
                      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed eu varius dui. Nunc id 
scelerisque ligula.</p>
                   </div>
                   <div class="services">
                   <img src="../app/images/1icontrash_03.png" alt="prototype">
                     <h3>Prototype</h3>
                      <p>Sed vestibulum mi quis est lacinia tempor. Praesent vitae commodo tellus. Cras eu est sem.</p>
                   </div>
                   <div class="services"> 
                   <img src="../app/images/1iconcamera_03.png" alt="photography">
                     <h3>Photography</h3>
                      <p>Donec tempus lacinia purus ut tincidunt. Nunc vel feugiat leo. Nunc iaculis hendrerit gravida. Nunc vel feugiat leo. </p>
                   </div>                           
                 </div>
            </div> 
          </section> 
   
<!--BANER-DO-YOU-->
         <section class="baner-do-you">
           <div class="container">
              <h2>Do you like this?</h2>
                     <ul class="buttonsp flex-container">     
                      <li><a href="#">Purchaise</a></li>
                      <li><a href="#">Follow</a></li>
                    </ul>
          </div>           
         </section>  

    
  <!--BANER-PORTFOLIO-->
    <section class="baner-portfolio">
           <div class="container">
             <h2>Portfolio</h2>
              <div class="buttons-portfolio">
                 <div><a href="#">Web-design</a></div>
                 <div><a href="#">UI design</a></div>
                 <div><a href="#">Prototype</a></div>
                 <div><a href="#">Photography</a></div>         
              </div> 
            </div>
        <div class="area">
           <div class="photography"><img src="../app/images/1.jpg" alt="girl-and-umbrella"></div> 
           <div class="photography"><img src="../app/images/2.jpg" alt="girl"></div> 
           <div class="photography"><img src="../app/images/3.jpg" alt="jump"></div> 
           <div class="photography"><img src="../app/images/4.jpg" alt="field"></div>  
           <div class="photography"><img src="../app/images/5.jpg" alt="car"></div> 
           <div class="photography"><img src="../app/images/6.jpg" alt="girl-with-cup"></div>
           <div class="photography"><img src="../app/images/8.jpg" alt="woman"></div>    
           <div class="photography"><img src="../app/images/7.jpg" alt="man"></div>  
         </div>   
    </section>
    
     <!--BANER-PRICING-TABLE-->
          <section class="baner-pricing">
           <div class="container">
              <h2>Pricing table</h2>
              <h3>Clean beautiful flat table</h3>
           </div>  
          </section>
     
     <!--BANER-OUR-PRICE-->  
         <section class="baner-our-price">
           <div class="container">
              <div class="our-price"> 
                <h2>Our price</h2>
              </div>
              <div class="prices-table"> 
                 <div class="prices-table1 flex-container">
                  <div class="columns">
                         <ul class= "price ">
                           <li class="header">Website hosting</li> 
                           <li class="mon"> $ 10 / month</li>
                           <li>2x option 1</li>
                           <li>2x option 1</li>
                           <li>2x option 1</li>
                           <li>2x option 1</li>
                           <li>2x option 1</li>
                           <li class="greyy"><a href="#" class="button">Purchaise</a></li>
                        </ul> 
                  </div> 
                  <div class="columns">
                        <ul class= "price ">
                            <li class="header">Website hosting</li> <li class="mon"> $ 10 / month</li>
                           <li>2x option 1</li>
                           <li>2x option 1</li>
                           <li>2x option 1</li>
                           <li>2x option 1</li>
                           <li>2x option 1</li>
                           <li class="greyy"><a href="#" class="button">Purchaise</a></li>
                        </ul> 
                  </div> 
                  <div class="columns">
                        <ul class= "price ">
                           <li class="header">Website hosting</li> 
                           <li class="mon"> $ 10 / month</li>
                           <li>2x option 1</li>
                           <li>2x option 1</li>
                           <li>2x option 1</li>
                           <li>2x option 1</li>
                           <li>2x option 1</li>
                           <li class="greyy"><a href="#" class="button">Purchaise</a></li>
                        </ul> 
                  </div> 
                  </div>
                <div class="prices-table1 flex-container">
                  <div class="columns">
                        <ul class= "price ">
                           <li class="header">Website hosting</li> 
                           <li class="mon1"> $ 10 / month</li>
                           <li>2x option 1</li>
                           <li>2x option 1</li>
                           <li>2x option 1</li>
                           <li>2x option 1</li>
                           <li>2x option 1</li>
                           <li class="greyy1"><a href="#" class="button1">Purchaise</a></li>
                        </ul> 
                  </div> 
                  <div class="columns">
                        <ul class= "price ">
                           <li class="header">Website hosting</li> 
                           <li class="mon2"> $ 10 / month</li>
                           <li>2x option 1</li>
                           <li>2x option 1</li>
                           <li>2x option 1</li>
                           <li>2x option 1</li>
                           <li>2x option 1</li>
                           <li class="greyy"><a href="#" class="button2">Purchaise</a></li>
                        </ul> 
                  </div>
                    <div class="columns">
                        <ul class= "price ">
                           <li class="header">Website hosting</li> 
                           <li class="mon3"> $ 10 / month</li>
                           <li>2x option 1</li>
                           <li>2x option 1</li>
                           <li>2x option 1</li>
                           <li>2x option 1</li>
                           <li>2x option 1</li>
                           <li class="greyy"><a href="#" class="button3">Purchaise</a></li>
                        </ul> 
                  </div> 
                 <div class="columns">
                        <ul class= "price ">
                           <li class="header">Website hosting</li> 
                           <li  class="mon4"> $ 10 / month</li>
                           <li>2x option 1</li>
                           <li>2x option 1</li>
                           <li>2x option 1</li>
                           <li>2x option 1</li>
                           <li>2x option 1</li>
                           <li class="greyy"><a href="#" class="button4">Purchaise</a></li>
                        </ul> 
                  </div> 
                   </div>   
              </div>
              </div> 
          
    <!--CLIENTS-ABOUT-US--> 
            <div class="clients-about-us">
                 <h3>CLIENTS ABOUT US</h3>
                    <div class= "boxx flex-container">
                      <div class="coment">
                        <p>Donec leo elit, dignissim eu elit vitae, aliquam tincidunt purus. Proin id risus ut sem vehicula faucibus. Fusce sed libero nec quam tempus facilisis. Vestibulum venenatis nisl ac feugiat aliquet. Sed euismod ligula arcu, et mollis est volutpat et. Aenean sed nulla placerat neque lacinia ullamcorper.</p>
                      </div>
                   </div>
                   <h4>PERRY MALITON </h4>
                </div>
          </section>
    
   <!--BANER-OUR-TEAM--> 
         <section class="baner-our-team">         
          <div class="container">
             <h2>Our team</h2>
             <h3>We a profesional and progressive team</h3>
          </div>
         </section> 
    
   <!--BANER-ABOUT-US-->
     <section class="baner-about-us">
        <div class="container">
               <div class="section-heading2">
                  <h2>About us</h2>
               </div>
            <div class="section-content2 flex-container">
                 <div class="team-member"><img src="../app/images/designer1.png" alt="Mark">
                    <h3>Mark Cream</h3>
                     <h4>Developer</h4>
                     <p>Curabitur congue libero mi, et lacinia sem blandit sit amet. Donec eu mi non magna rhoncus bibendum et eu dui. Nunc iaculis placerat sapien vel imperdiet. </p>
                 </div>
                 <div class="team-member"><img src="../app/images/fireeffects.jpg" alt="Antonio">
                     <h3>Antonio Paramo</h3>
                     <h4>Fire Effects</h4>
                     <p>Etiam pulvinar libero et scelerisque cursus. Sed eu nisl congue, gravida urna imperdiet, laoreet dolor. Morbi adipiscing neque erat, tincidunt 
porttitor est vestibulum ac. </p>
                 </div>
                 <div class="team-member"><img src="../app/images/boss.jpg" alt="Mario">
                     <h3>Mario Ballote</h3>
                     <h4>Big Boss</h4>
                     <p>Donec at pulvinar dolor, et lobortis est. Phasellus nibh nisi, blandit non velit sit amet, pulvinar vehicula nulla.</p>
                 </div> 
                 <div class="team-member"><img src="../app/images/designer2.jpg" alt="Ben">
                     <h3>Ben Bugatton</h3>
                     <h4>Designer</h4>
                     <p>Mauris dignissim felis quis justo 
malesuada gravida. Sed quis neque condimentum, luctus augue in, dapibus sapien.</p>
                 </div> 
              </div>
                  <div class="skills">
                   <h2>OUR SKILLS</h2>
                 </div>
                  <div class="our-skills flex-container">
                      
                      <div class="skills1">
                        <img src="../app/images/webdesign.png" alt="web-design">
                       </div>
                   
                       <div class="skills1">
                       <img src="../app/images/creative.png" alt="creative">
                       </div>
                   
                        <div class="skills1">
                       <img src="../app/images/creative.png" alt="ui-design">
                       </div>                  
                       
                        <div class="skills1">
                        <img src="../app/images/prototypes.png" alt="prototypes">
                        </div>
                   
                        <div class="skills1">
                        <img src="../app/images/photography.png" alt="photography">
                        </div>                
                  </div>  
          </div>
        </section> 
    
   <!--BANER-YOU-LOOKED-->   
         <section class="baner-you-looked">
           <div class="container">             
                <h2>YOU LOOKED OVER 6000 PX</h2>
                <h3>Thats Great!</h3>
            </div>
         </section> 
    
    <!--BANER-CONTACT-US--> 
    <section class="kontakt">
        <div class="container">
            <div class="section-heading3">
                <h2>Contact us</h2>
                <p></p>
            </div>
            <div class="section-content3">
                <form class="contact-form" action="index.php" method= "post">
                    <div class="input-row">
                        <input type="text" name="vardas" placeholder="Your Name*" required autofocus>
                        <input type="email" name="email" placeholder="Your Email*" required>
                    </div>
                        <textarea name="message" rows="8" placeholder="Your Message*" required></textarea>
                    <input class="btn btn-form" type="submit" name="submit">
                </form>
            </div>
        </div>
    </section>
    
       <!--BANER-CONNECT-WITH-US--> 
         <section class="baner-connect-with-us">
            <div class="container"> 
             <h2>CONNECT WITH US</h2>
             <h3>Follow Us On Social Networks</h3>
               <nav class="nav social-nav">
                 <ul class="flex-container">
                   <li><a href="#"> <i class="fa fa-twitter" aria-hidden="true"></i></a></li>  
                   <li><a href="#"> <i class="fa fa-facebook" aria-hidden="true"></i></a></li>  
                   <li><a href="#"> <i class="fab fa-github-alt" aria-hidden="true"></i></a></li>  
                   <li><a href="#"> <i class="fab fa-pinterest-p" aria-hidden="true"></i></a></li>  
                   <li><a href="#"> <i class="fab fa-tumblr" aria-hidden="true"></i></a></li>  
                   <li><a href="#"> <i class="fab fa-vimeo-v" aria-hidden="true"></i></a></li>             
                   <li><a href="#"> <i class="fab fa-flickr" aria-hidden="true"></i></a></li> 
                  </ul>
                </nav>
            </div>     
          </section>
    <!--FOOTER--> 
     <header class="footer">
        <div class="container1 flex-container">
            <div class="logo">
                <img src="../app/images/logo.png" alt="Parallels-logo">
                <p class="copyright">&copy;<?php echo date('Y'); ?>. </p>
            </div>
            <nav class="main-nav">
                <ul class="foot flex-container">
                    <li><a href="tel:1234567890">123-456-7890</a></li>
                    <li><a href="mailto:someone@yoursite.com">Email Us</a> </li> 
                    <li><a href="skype:<username>?<action>"> skype:username</a></li>
                </ul>
            </nav>
        </div>
    </header>
</body>
</html>
